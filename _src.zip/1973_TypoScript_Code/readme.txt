Each chapter has its own code folder. It has the code related to that chapter.
Most of the code is in the text format.
You can copy the code from the text file and paste it into the corresponding field.

Thanks!